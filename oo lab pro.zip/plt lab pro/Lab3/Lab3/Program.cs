﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3
{
    class Program
    {
        public int emp_id, pin;
        public string emp_name, emp_email, ad1, ad2, city;
        char emp_gen;
        public static Program p;
        public Program() 
        {
            p = this;
        }
       
        static void Main(string[] args)
        {
            Employee Emp = new Employee();
            //Program p=new Program();

            StoreData(Emp);

            ShowData(Emp);
        }

        static void StoreData(Employee Emp)
        {
            Emp.Name= CustomConsole.ReadString();
            Emp.Gender= CustomConsole.ReadChar();
            Emp.EmployeeId= CustomConsole.ReadInt();
            Address ad=new Address();
            ad.City= CustomConsole.ReadString();
            ad.Address1 = CustomConsole.ReadString();
            ad.Address2 = CustomConsole.ReadString();
            ad.PinCode = CustomConsole.ReadInt();
            Emp.EmpAddress = ad;







    }

        static void ShowData(Employee Emp)
        {

            //----------------Display the employee information
            Console.WriteLine("Employee Id : "+ Emp.EmployeeId);
            Console.WriteLine("Employee Name : "+Emp.Name);
            Console.WriteLine("Employee Gender : "+Emp.Gender);

            Console.WriteLine("Employee Address : --------------");
            Address ade = Emp.EmpAddress;
            Console.WriteLine("Address 1 : "+ ade.Address1);
            Console.WriteLine("Address 2 : "+ade.Address1);
            Console.WriteLine("City : "+ade.City);
            Console.WriteLine("PinCode : "+ade.PinCode);
            Console.WriteLine("----------------------------------");

            Console.ReadLine();
        }
    }
}
