﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3
{
    class Address
    {
        /// <summary>
        /// Properties of the class
        /// </summary>
        internal string emp_add1;
        internal string emp_add2;
        internal string emp_city;
        internal int emp_pin;

        public string Address1 {
            get
            {
                return emp_add1;
            }
            set 
            { 
                emp_add1 = value;
            } 
        }
        public string Address2 {
            get
            {
                return emp_add2;
            }
            set
            {
                emp_add2 = value;
            }
        }
        public string City {
            get
            {
                return emp_city;
            }
            set
            {
                emp_city = value;
            }
        }
        public int PinCode 
        {
            get
            {
                return emp_pin;
            }
            set
            {
                emp_pin = value;
            }

        }
    }
}
