﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3
{
    /// <summary>
    /// Class to represent employee information
    /// </summary>
    class Employee
    {
        /// <summary>
        /// Properties of the class
        /// </summary>

        internal int emp_id;
        internal string emp_name;
        internal string emp_email;
        internal char emp_gen;
        internal string emp_add;
        Address ade = new Address();
        public int EmployeeId
        {
            get
            {
                return emp_id;
            }
            set
            {
                emp_id = value;
            }



        }
        public string Name
        {
            get
            {
                return emp_name;
            }
            set
            {
                emp_name =value;
            }
        }
        public char Gender
        {
            get
            {
                return emp_gen;
            }
            set
            {
                emp_gen = value;
            }
        }
        public Address EmpAddress
        {
            


            get
            {
                return ade;
            }
            set
            {
             
                
                ade= value;
            }
        }
    }
}
