﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LabT11
{
    class RoleBuilder
    {
        

        /// <summary>
        /// Method to get role description for a given role id
        /// </summary>
        /// <param name="RoleId"></param>
        /// <returns>Description of a role id</returns>
        public static string GetRoleDescription(int RoleId)
        {
            if ((RoleId >= 1 && RoleId <= 4))
            {
                if (RoleId == 1)
                {
                    return "DEVELOPER";
                }
                else if (RoleId == 2)
                {
                    return "TEST_ENGINEER";
                }
                else if (RoleId == 3)
                {
                    return "SR_DEVELOPER";
                }
                else
                {
                    return "DESIGNER";
                }
            }
            else
            {
                return "Undefined";
            }
        }
    }
}
