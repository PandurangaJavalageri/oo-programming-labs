﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LabT11
{
    enum Roles
    {
        DEVELOPER=1,
        SR_DEVELOPER,
        TEST_ENGINEER,
        DESIGNER
    }
}
