﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter three marks");
            stu s=new stu();
            s.mark1=int.Parse(Console.ReadLine());
            s.mark2 =int.Parse(Console.ReadLine());
            s.mark3 =int.Parse(Console.ReadLine());
            s.display();
            s.result();
            



        }
    }
    public class stu
    {
        public string Name { set; get; }
        public int mark1 { set; get; }
        public int mark2 { set; get; }
        public int mark3 { set; get; }
        public void result()
        {
            double avg = (mark1 + mark2 + mark3) / 3;
            if (avg > 35)
            {
                if (avg >= 60)
                {
                    Console.WriteLine("first class");
                }
                else if (avg >= 50 && avg < 60)
                {
                    Console.WriteLine("sewcond class");
                }
                else
                {
                    Console.WriteLine("pass");

                }
            }
            else
            {
                Console.WriteLine("fail");
            }
        }
        public void display()
        {
            double total, avg;
            total = mark1 + mark2 + mark3;
            avg = total / 3;
            Console.WriteLine($"averge {avg} total {total}");

        }
    }

}
