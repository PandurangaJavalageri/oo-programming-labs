﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1,n=7;
            while(true)
            {
                n = 7 * i;
                if(n%2==1 && n%3==1 && n%4==1 && n%5==1 && n%6==1)
                {
                    Console.WriteLine(n);
                    break;
                }
                i++;
            }
            i++;
            while (true)
            {
                n = 7 * i;
                if (n % 2 == 1 && n % 3 == 1 && n % 4 == 1 && n % 5 == 1 && n % 6 == 1)
                {
                    Console.WriteLine(n);
                    break;
                }
                i++;
            }
            i++;
            while (true)
            {
                n = 7 * i;
                if (n % 2 == 1 && n % 3 == 1 && n % 4 == 1 && n % 5 == 1 && n % 6 == 1)
                {
                    Console.WriteLine(n);
                    break;
                }
                i++;
            }


        }
    }
}
