﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Numberinwords
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            n = int.Parse(Console.ReadLine());
            string s = "";
            int sum = 0;
            while(n>0)
            {
                int temp = n % 10;
                sum = sum * 10 + temp;
                n = n / 10 ;
            }
            Dictionary<int,string> dic = new Dictionary<int,string>();
            dic.Add(0, "zero");
            dic.Add(1, "one");
            dic.Add(2, "two");
            dic.Add(3, "three");
            dic.Add(4, "four");
            dic.Add(5, "five");
            dic.Add(6, "six");
            dic.Add(7, "seven");
            dic.Add(8, "eight");
            dic.Add(9, "nine");
            while(sum> 0)
            {
                int temp=sum% 10;
                s += dic[temp];
                s += " ";
                sum = sum / 10;

            }
            Console.WriteLine(s);
        }
    }
}
