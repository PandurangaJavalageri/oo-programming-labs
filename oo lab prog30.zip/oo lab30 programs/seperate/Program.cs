﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seperate
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a num");
            double n=Convert.ToDouble(Console.ReadLine());
            seper(n);
        }
        public static void seper(double n)
        {

            int I = Convert.ToInt32(n);
            double f = n - I;
            Console.WriteLine($"fraction {f} and integer {I}");
        }
    }
   
}
