﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n=int.Parse(Console.ReadLine());
            //series1(n);
            //Console.WriteLine();
            //series2(n);
            //Console.WriteLine();
            //series3(n);
            //Console.WriteLine();
            //series5(n);
            Console.WriteLine();
            series6(n);
        }
        public static void series1(int n)
        {
            int i = 2;
            if (n % 2 == 0)
            {
                n = n + 1;
            }
            for (i = 2; i < n;)
            {
                Console.Write(Math.Pow(i, 2)+"\t");
                i = i + 2;
            }
        }
        public static void series2(int n)
        {
            for(int i=1;i<=n;i++)
            {
                if (i % 2 == 0)
                    Console.Write("-"+i+"\t"); 
                else
                    Console.Write(i+"\t");
            }
        }
        public static void series3(int n)
        {
            for (int i=1;i<=n; i++)
            {
                Console.Write(Math.Pow(i,i)+"\t");
            }
        }
        public static void series5(int n)
        {
            for(int i=1;i<=n;i++)
            {
                Console.Write(Math.Pow(i,2)+"\t");
                if(i%3==0)
                {
                    i++;
                }

            }
        }
        public static void series6(int n)
        {
            double prev = 1,num=1;
            for(int i=0;prev<n;i++)
            {
                num = prev + Math.Pow(i, 4);
                Console.Write(num+"\t");
                prev = num;
                if(i%2==0)
                {
                    i = i + 1;
                }
            }
        }
        
    }
}
