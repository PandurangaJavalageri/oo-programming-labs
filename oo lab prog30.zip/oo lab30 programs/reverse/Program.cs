﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reverse
{
    internal class Program
    {
        /// <summary>
        /// =0
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int n,sum=0;
            n = int.Parse(Console.ReadLine());
            while(n>0)
            {
                int temp = n % 10;
                sum = sum * 10 + temp;
                n = n / 10;
            }
            Console.WriteLine(sum);
        }
    }
}
