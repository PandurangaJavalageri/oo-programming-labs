﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pal
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a string");
            string s = Console.ReadLine();
            string ans = "";
            for (int i = s.Length - 1; i >= 0; i--)
            {
                ans += s[i];
            }
            Console.WriteLine(ans);
            if(ans==s)
            {
                Console.WriteLine("it's a palindrome");
            }
            else { Console.WriteLine("it's not a palindrome"); }
        }
    }
}
