﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace primenumber13
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int n, m;
            Console.WriteLine("enter range of number");
            n=int.Parse(Console.ReadLine());
            m=int.Parse(Console.ReadLine());
            prime(n, m);
        }
        public static void prime(int n, int m)
        {
            int sum = 0;
            for(int i=n;i<=m;i++)
            {
                int flag = 0;
                for(int j=2;j<=Math.Sqrt(i);j++)
                {
                    if(i%j==0)
                    {
                        flag = 1;
                        continue;
                    }
                }
                if(flag == 0)
                {
                    Console.Write(i+"\t");
                    sum=sum + i;
                }

            }
            Console.WriteLine($"sum is {sum}");
        }
    }
}
