﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLT_labs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int principle, interest_rate, time,interest;
            Console.WriteLine("enter the principle");
    
            principle =int.Parse(Console.ReadLine());
            Console.WriteLine("enter the interest rate");
            interest_rate = int.Parse(Console.ReadLine());
            Console.WriteLine("enter  the time");
            time= int.Parse(Console.ReadLine());
            interest = simple_calc(principle, interest_rate,time);
            Console.WriteLine($"principle:{principle} interestrate :{interest_rate} time:{time} interest {interest}");

        }
        public static int simple_calc(int p,int r,int t)
        {
            int res = (p * t * r) / 100;
            return res;
        }
        public void displaytwonum()
        {
            int number1=int.Parse(Console.ReadLine());
            int number2=int.Parse(Console.ReadLine());  

        }
        public void swap(int n1,int n2)
        {
            int temp = n1;
            n1 = n2;
            n2 = temp;
        }
    }
}
