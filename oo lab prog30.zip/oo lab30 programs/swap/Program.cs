﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace swap
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("enter two number");
            n1 = int.Parse(Console.ReadLine());
            n2= int.Parse(Console.ReadLine());
            Console.WriteLine("before swapping");
            displaytwonum(ref n1,ref  n2);
            swap(ref n1,ref n2);
            Console.WriteLine("after swapping");
            displaytwonum(ref n1, ref n2);

        }
        public static void displaytwonum(ref int n1,ref int n2)
        {
            Console.WriteLine("two numbers{0},{1}",n1,n2);

        }
        public static void swap(ref  int n1,ref  int n2)
        {
            int temp = n1;
            n1 = n2;
            n2 = temp;
        }
    }
}
