﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decitobin
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string s = "";
            int sum=0;
            int n=int.Parse(Console.ReadLine());
            //while (n>0)
            //{
            //    int rem=n%10;
            //     sum = sum * 10 + rem;
            //    n = n / 10;
            //}
            //n=sum;
            while(n>0)
            {
                int rem = n % 2;
                string c= rem.ToString();
                s += c;
                n = n / 2;
            }
            string ans=new string(s.Reverse().ToArray());
            Console.WriteLine($"convert to integer {ans}");

        }
    }
}
