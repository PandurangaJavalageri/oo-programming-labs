﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace large
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3,first,sec;
            Console.WriteLine("enter three number");
            n1 =int.Parse(Console.ReadLine());
            n2=int.Parse(Console.ReadLine());
            n3=int.Parse(Console.ReadLine());
            if(n1>n2 && n1>n3)
            {
                first = n1;
                sec = Math.Max(n2, n3);
                Console.WriteLine($"{n1} is first largest {sec} is second");
            }
            else if(n2>n1 && n2>n3)
            {
                first = n2;
                sec=Math.Max(n1, n3);
                Console.WriteLine($"{n2} is first largest {sec} is second");
            }
            else
            {   first = n3;
                sec= Math.Max(n1, n2);
                Console.WriteLine($"{n3} is first largest  {sec}  is second");
            }
            
            
           
        }
    }
}
