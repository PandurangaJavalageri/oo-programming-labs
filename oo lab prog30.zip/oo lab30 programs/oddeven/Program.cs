﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oddeven
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter  a number");
            int num = int.Parse(Console.ReadLine());
            oe(num);
        }

        public static void oe(int n1)
        {
            if(n1%2==0)
            {
                Console.WriteLine("it's even");
            }
            else
            {
                Console.WriteLine("it's odd");
            }
        }

    }
}
