﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace salary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            emp e=new emp();
            Console.WriteLine("enter employee details");
            e.name=Console.ReadLine();
            e.empid=int.Parse(Console.ReadLine());
            e.basic = int.Parse(Console.ReadLine());
            e.specialallowance = int.Parse(Console.ReadLine());
            e.bonusper=double.Parse(Console.ReadLine());
            e.investments=int.Parse(Console.ReadLine());
            e.annualsal();
            e.grosssal();
            e.annualnet();
            

        }

    }
    public class emp
    {
        double sal, grossal, annet;
        public string name
        {
            get; set;
        }
        public int empid { get; set; }
        public int basic { get; set; }
        public int specialallowance { get; set; }
        public double bonusper { get; set; }
        public int investments { get; set; }
        public void annualsal()
        {
            sal = (basic + specialallowance)*12;
            Console.WriteLine($"details of {name} and {empid}");
            Console.WriteLine($"sal is {sal}");

        }
        public void grosssal()
        {

            grossal = sal + (sal * bonusper)/ 100;
            Console.WriteLine($"sal is {grossal}");
        }
        public void annualnet()
        {
            if (grossal > 100000)
            {
                if (investments*12 > 100000)
                {
                    annet = grossal- 100000;
                }
                else
                {
                    annet = grossal- investments*12;
                }
            }
            else
            {
                annet = grossal;
                Console.WriteLine($"annual net sal is {annet} taxable is "+0);
                return;
            }
            double taxablesal;
            if (annet > 100000 && annet <= 150000)
            {
                annet = annet * .8;
                taxablesal = 50000;
            }
            else if (annet > 150000)
            {
               
              
                 taxablesal = annet - 150000;
                annet = annet - .3 * taxablesal-10000;
                taxablesal += 50000;
            }
            else
            {
                annet = grossal;

               // Console.WriteLine($"gross sal{grossal} and annet {annet}");
            }
            if(investments*12>100000)
            {
                annet = annet + 100000;
            }
            else
            {
                annet=annet+investments*12;
            }
            Console.WriteLine($"annual net sal is {annet}");
        }
    }

}
