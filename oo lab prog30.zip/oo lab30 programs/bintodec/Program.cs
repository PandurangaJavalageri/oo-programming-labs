﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bintodec
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string s=Console.ReadLine();
            double sum = 0;
            string ans=new string(s.Reverse().ToArray());
            Console.WriteLine(ans);
            for(int i=0;i<ans.Length; i++)
            {
                //Console.WriteLine(ans[i]);
                double temp = (double)(ans[i]-'0');
                sum=sum+temp *Math.Pow(2,i);
                //Console.WriteLine(sum);

            }
            Console.WriteLine($"sum is {sum}");
        }
    }
}
