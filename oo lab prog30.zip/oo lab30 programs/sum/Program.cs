﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number");
            int n=int.Parse(Console.ReadLine());
            int sum = 0;
            for(int i=1;i<=n;i++)
            {
                sum += i;
                i = i + 2;
            }
            Console.WriteLine(sum);
        }
    }
}
