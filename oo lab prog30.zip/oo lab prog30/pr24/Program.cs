﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr24
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n=int.Parse(Console.ReadLine());
            //series1(n);
            //series2(n);
           //series3(n);
            series4(n);

        }
        public static void series1(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write($"{j+1}  ");
                }
                Console.WriteLine();
            }
        }
        public static void series2(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write($"{i + 1}  ");
                }
                Console.WriteLine();
            }
        }
        public static void series3(int n)
        {
            int count = 1;
            for (int i = 0; i < n; i++)
            {
               
                for (int j = 0; j <= i; j++)
                {
                    Console.Write($"{count}  ");
                    count++;
                }
                Console.WriteLine();
                //count++;
            }
            
        }
        public static void series4(int n)
        {
            int prev1, prev2;
            Console.WriteLine(1);
            Console.WriteLine(1+" "+2);
            prev1=1;
            prev2=2;
            for(int i = 2;i < n;i++)
            {
                for(int j = 0;j <= i;j++)
                {
                    int current = prev2 + prev1;
                    Console.Write(current+" ");
                    prev1 = prev2;
                    prev2=current;
                }
                Console.WriteLine();
            }

        }

    }
}
