﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace binarysearch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            Console.WriteLine("enter the size of array");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the elements");
            for (int i = 0; i < n; i++)
            {
                list.Add(int.Parse(Console.ReadLine()));
            }
            int key = int.Parse(Console.ReadLine());
            int low=0, high=list.Count-1;
            while(low < high) 
            {
                int mid = (low+high)/2;
                if (list[mid]==key)
                {
                    Console.WriteLine($"key found at this position{mid}");
                    return;
                }
                else if (key > list[mid])
                {
                    low = mid + 1;
                }
                else
                {
                    high = mid - 1;
                }


            }
            Console.WriteLine("element not found");
        }
    }
}
