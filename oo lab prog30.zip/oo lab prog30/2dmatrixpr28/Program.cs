﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2dmatrixpr28
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int m, n;
            Console.WriteLine("enter row and col");
            m = int.Parse(Console.ReadLine());
            n = int.Parse(Console.ReadLine());
            int[,] a = new int[m, n];
            int i = 0, j = 0;
            Console.WriteLine("enter the elements of the array");
            for( i = 0; i < m; i++)
            {
                for(j = 0; j < n; j++)
                {
                    a[i,j]=(int.Parse(Console.ReadLine()));
                }
                
            }
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    Console.Write(a[i,j]+"\t");
                }
                Console.WriteLine();

            }
            int[,] rev=new int[n, m];
            for( i=0;i< n; i++)
            {
                for( j=0;j< m; j++)
                {
                    rev[i, j] = a[j, i];
                }
            }
            Console.WriteLine(rev[1,0]);
            for ( i=0;i<n; i++) 
            {
                for(j=0; j<m; j++)
                {
                    Console.Write(rev[i,j]+"\t");
                }
                Console.WriteLine();
            }

        }
    }
}
