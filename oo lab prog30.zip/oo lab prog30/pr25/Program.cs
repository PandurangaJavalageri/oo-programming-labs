﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            //series1(n);
            //series2(n);
            //series3(n);
            series4(n);
        }
        public static void series1(int n)
        {
            int count = 1;
                for (int i = 0; i < n; i++)
                {
                for (int j = 0; j <= i; j++)
                    {
                    if ((count) % 2 == 0)
                    {
                        Console.Write("-" + Math.Pow(count, 2)+" ");

                    }
                    else
                    {
                      Console.Write( Math.Pow(count, 2)+" ");

                    }
                    count++;
                }
                }
                    Console.WriteLine();
        }
        public static void series3(int n)
        {
            int count = 1;
            for(int i = 0;i < n; i++)
            {
                for(int j=0;j<=n-i+1;j++)
                {
                    Console.Write(" ");
                }
                for (int j = 0; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
           
        }
        public static void series4(int n)
        {
            int count = 1;
            for (int i = 0; i < n;i++)
            {
                int tot=2*n-1;
                for(int j = 0;j<=(tot-count)/2;j++)
                {
                    Console.Write(" ");
                }
                for(int j = 0;j<count;j++)
                {
                    if (j != count - 1)
                        Console.Write("* ");
                    else Console.Write("*");
                }
                for (int j = 0; j <=(tot - count)/2; j++)
                {
                    Console.Write(" ");
                }
                count += 2;
                Console.WriteLine();
            }
        }
        public static void series2(int n)
        {
            Console.WriteLine(1);
            Console.WriteLine(1+" "+2);
            int count = 3, prev = 2;
            for(int i = 2;i < n;i++)
            { 
                for(int j = 0;j<=i;j++)
                {
                    int curr = prev * count;
                    prev = curr;
                    Console.Write(curr+" ");
                    count++;
                }
                Console.WriteLine();


            }
        }


    }
}
