﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr30
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int m, n;
            Console.WriteLine("enter row and col");
            m = int.Parse(Console.ReadLine());
            n = int.Parse(Console.ReadLine());
            int[,] a = new int[m, n];
            int i = 0, j = 0;
            Console.WriteLine("enter the elements of the array");
            if(m!=n)
            {
                Console.WriteLine("symmetric cannot be formed");
            }
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    a[i, j] = (int.Parse(Console.ReadLine()));
                }

            }
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    if (a[i, j] != a[j,i])
                    {
                        Console.WriteLine("matrix is not a symmetric");
                    }
                }
            }
            Console.WriteLine("it's a symmetric matrix");
        }
    }
}
