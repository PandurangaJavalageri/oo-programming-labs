﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr20
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x, n,res=1;
            x = int.Parse(Console.ReadLine());
            n = int.Parse(Console.ReadLine());
            for(int i=0;i<n;i++)
            {
                res *= x;
            }
            Console.WriteLine(res); 
        }
    }
}
