﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linearsearch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            Console.WriteLine("enter the size of array");
            int n=int.Parse(Console.ReadLine());
            Console.WriteLine("enter the elements");
            for(int i=0; i<n; i++)
            {
                list.Add(int.Parse(Console.ReadLine()));
            }
            int key=int.Parse(Console.ReadLine());
            for(int i=0; i<n;i++)
            {
                if (list[i] == key)
                {
                    Console.WriteLine($"key found at {i} position");
                    return;
                }
                    
            }
            Console.WriteLine("not found");

        }
    }
}
