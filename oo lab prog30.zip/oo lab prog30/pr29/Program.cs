﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr29
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int m, n;
            Console.WriteLine("enter row and col");
            m = int.Parse(Console.ReadLine());
            n = int.Parse(Console.ReadLine());
            int[,] a = new int[m, n];
            int i = 0, j = 0;
            Console.WriteLine("enter the elements of the array");
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    a[i, j] = (int.Parse(Console.ReadLine()));
                }

            }
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    if ((a[i,j] != 1 && i == j)|| (a[i,j]!=0 && i!=j))
                    {
                        Console.WriteLine("not an identity matrix");
                        return;
                    }


                }
               

            }
            Console.WriteLine("it's a identity matrix");

        }
    }
}
