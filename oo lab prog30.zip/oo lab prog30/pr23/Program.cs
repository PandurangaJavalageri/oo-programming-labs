﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            n=int.Parse(Console.ReadLine());

        }
        public static void series1()
        {
            for(int i = 0; i < n; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.WriteLine("*");
                }
                Console.WriteLine();
            }
        }
        public static void series2(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.WriteLine("i+1");
                }
                Console.WriteLine();
            }

        }
        public static void  series3(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.WriteLine("j+1");
                }
                Console.WriteLine();
            }
        }
        public static void series4(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <=i; j++)
                {
                    Console.WriteLine("*");
                }
                Console.WriteLine();
            }
        }
    }
}
