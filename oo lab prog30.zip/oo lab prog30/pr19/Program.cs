﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            n = int.Parse(Console.ReadLine());
            //series1(n);
            //series2(n);
            //series3(n);
            series4(n);
            Console.WriteLine();

        }
        public static void series1(int n)
        {
            double prev = 1,i=1,curr=1;
            Console.Write(prev+" ");
            while (curr < n) 
            {
                curr = Math.Pow(i, 2) + prev;
                if (i%2!= 0)
                Console.Write("-"+curr+" ");
                else
                    Console.Write(curr+" ");
                prev= curr;
                i++;
            }
            Console.WriteLine();
        }
        public static void series2(int n) 
        {
            int first = 1, sec = 1,curr=first+sec;
            Console.WriteLine(1+""+1+" ");
            while(curr < n)
            {
                curr = first + sec;
                Console.Write(curr+" ");
                first=sec;
                sec=curr;

            }
            Console.WriteLine();
        }
        public static void series3(int n)
        {
            int first=1,ct1=3,ct2= -4,sec=-2,i=3;
            Console.Write(1+" "+-2+" ");
            while (first <= n&& sec!=n)
            {
                if(i%2!=0)
                {
                    Console.Write(first + 3 + " ");
                    first = first + 3;
                }
                    
                else
                {
                    Console.Write(sec - 4 + " ");
                    sec = sec - 4;
                }
                  

                i++;
                
            }
            Console.WriteLine();


        }
        public static void series4(int n)
        {
            Console.Write(1+" "+5+" "+8+" ");
            int curr = 0,first=1,sec=5,third=8;
            while(curr<n)
            {
                curr = first + sec + third;
                Console.Write(curr+" ");
                first=sec;
                sec=third;
                third=curr;
            }
        }
    }
}
