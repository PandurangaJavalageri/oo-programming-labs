﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr18
{
    internal class Program
    {
        public static int grandtotal = 0;
        static void Main(string[] args)
        {
            int choice;
            Console.WriteLine("enter your choice");
            choice = int.Parse(Console.ReadLine());
            while(choice!=0)
            {
                calc();
                Console.WriteLine("enter your choice");
                choice = int.Parse(Console.ReadLine());
            }
            Console.WriteLine($"total amount spent {grandtotal}");


        }
        public static void calc()
        {
            item i=new item();
            Console.WriteLine("enter item id");
            i.itemid = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the item name");
            i.name=(Console.ReadLine());
            Console.WriteLine("enter the item price");
            i.price = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the item quantity");
            i.quantity = int.Parse(Console.ReadLine());
            grandtotal+=i.quantity*i.price;


        }
        public class item
        {
            public int itemid { get; set; }
            public string name { get; set; }
            public int price { get; set; }
            public int quantity { get; set; }
        }
    }
}
