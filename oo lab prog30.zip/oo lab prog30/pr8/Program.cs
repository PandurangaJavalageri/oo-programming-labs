﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int vendorrate,noofhours,cons,constime, consp, infra,infraamount, license,licenseamount,com,ucom;
            Console.WriteLine("enter the no of hours spent on doing that project");
            noofhours=int.Parse(Console.ReadLine());
            Console.WriteLine("amount paid per hour");
            vendorrate=int.Parse(Console.ReadLine());
            Console.WriteLine("no of consultants used");
            cons=int.Parse(Console.ReadLine());
            Console.WriteLine("amount paid to cons per hour");
            consp=int.Parse(Console.ReadLine());
            Console.WriteLine("no of hours spent by consultant");
            constime =int.Parse(Console.ReadLine());
            Console.WriteLine("did he use any new infra");
            infra =int.Parse(Console.ReadLine());
            Console.WriteLine("did he use any licens");
            license=int.Parse(Console.ReadLine());
            Console.WriteLine("license common");
            com =int.Parse(Console.ReadLine());
            Console.WriteLine("license amount");
            licenseamount =int.Parse(Console.ReadLine());
            Console.WriteLine("enter the amount spent on infra");
            infraamount =int.Parse(Console.ReadLine());
            int profit;
            profit=(noofhours*vendorrate)-(cons*constime*consp);
            if(infra==1)
            {
                profit = profit - (int)(.7 * infraamount);
            }
            if(license==1)
            {
                if(com==1)
                {
                    profit = profit - (int)(.5 * licenseamount);
                }
                else
                {
                    profit = profit - licenseamount;
                }
            }
            if(profit>0)
            {
                Console.WriteLine($"vendor earned {profit}");
            }
            else
            {
                Console.WriteLine("vendor earned loss{profit}");
            }



        }
    }
}
